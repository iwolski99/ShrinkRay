plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Values come from config.yaml via the GitHub workflow (-PappName=... etc).
// The defaults below are used if a value is missing.
fun cfg(name: String, default: String): String =
    (project.findProperty(name) as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: default

fun mb(name: String, default: String): String =
    "${(cfg(name, default).toDouble() * 1024 * 1024).toLong()}L"

fun javaString(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

fun xmlString(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
    .replace("'", "\\'").replace("\"", "\\\"")

android {
    namespace = "com.shrinkray.app"
    compileSdk = 34

    defaultConfig {
        applicationId = cfg("appId", "com.shrinkray.app")
        minSdk = 30
        targetSdk = 34
        versionCode = cfg("versionCode", "1").toInt()
        versionName = cfg("versionName", "1.0")

        resValue("string", "app_name", xmlString(cfg("appName", "ShrinkRay")))

        buildConfigField("int", "JPEG_QUALITY", cfg("jpegQuality", "88"))
        buildConfigField("int", "MAX_LONG_SIDE", cfg("maxLongSide", "4000"))
        buildConfigField("long", "PHOTO_MIN_BYTES", mb("photoMinMb", "1.5"))
        buildConfigField("long", "VIDEO_MIN_BYTES", mb("videoMinMb", "10"))
        buildConfigField("long", "AUDIO_MIN_BYTES", mb("audioMinMb", "2"))
        buildConfigField("String", "VIDEO_CODEC", javaString(cfg("videoCodec", "hevc")))
        buildConfigField("String", "VIDEO_QUALITY", javaString(cfg("videoQuality", "balanced")))
        buildConfigField("int", "MIN_SAVINGS_PERCENT", cfg("minSavingsPercent", "15"))
        buildConfigField("int", "AUDIO_BITRATE_KBPS", cfg("audioBitrateKbps", "256"))
    }

    signingConfigs {
        create("release") {
            val ks = System.getenv("KS_PATH")
            if (ks != null && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = System.getenv("KS_PASS")
                keyAlias = System.getenv("KS_ALIAS")
                keyPassword = System.getenv("KEY_PASS")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (System.getenv("KS_PATH") != null)
                signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        resources.excludes += "/META-INF/versions/**"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Reads/writes song info + album art (tested with FLAC, MP3, WAV, M4A, OGG, AIFF)
    implementation("net.jthink:jaudiotagger:3.0.1")
}
