package com.shrinkray.app

import android.content.Context
import android.net.Uri
import kotlin.math.min

enum class Kind(val label: String) { PHOTO("Photos"), VIDEO("Videos"), AUDIO("Audio"), OTHER("Other") }

/** The tabs across the top of the app. */
enum class Tab(val label: String, val kind: Kind?) {
    PHOTO("Photos", Kind.PHOTO), VIDEO("Videos", Kind.VIDEO), AUDIO("Audio", Kind.AUDIO), DOWNLOADS("Downloads", null)
}

enum class SortOrder(val label: String) {
    LARGEST("Largest first"), SMALLEST("Smallest first"), NEWEST("Newest first"), OLDEST("Oldest first"), NAME("Name A–Z")
}

/** File-type label used by the type filter: "WAV", "MP3", "FLAC", "JPG", ... */
fun typeLabel(ext: String): String = when (ext.lowercase()) {
    "jpeg" -> "JPG"
    "aif" -> "AIFF"
    "m4v" -> "MP4"
    "" -> "No extension"
    else -> ext.uppercase()
}

data class MediaFile(
    val uri: Uri,
    val path: String,
    val name: String,
    val folder: String,
    val size: Long,
    val kind: Kind,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    /** Date taken in ms since epoch, 0 if unknown. */
    val dateTaken: Long,
    /** Best date to show in the list (taken, else modified), ms. */
    val displayDate: Long,
    /** If set, the file is listed (Downloads tab) but can't be selected, and this says why. */
    val blockedReason: String? = null,
) {
    val ext: String get() = path.substringAfterLast('/').substringAfterLast('.', "").lowercase()
    val type: String get() = typeLabel(ext)
}

sealed interface ItemStatus {
    data object Working : ItemStatus
    data class Done(val oldSize: Long, val newSize: Long) : ItemStatus
    data class Skipped(val reason: String) : ItemStatus
    data class Failed(val reason: String) : ItemStatus
}

/** User-adjustable settings. Defaults come from config.yaml (baked into BuildConfig). */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var jpegQuality: Int
        get() = p.getInt("jpegQuality", BuildConfig.JPEG_QUALITY).coerceIn(40, 100)
        set(v) = p.edit().putInt("jpegQuality", v).apply()

    /** Longest side in pixels for photos. 0 = keep original resolution. */
    var maxLongSide: Int
        get() = p.getInt("maxLongSide", BuildConfig.MAX_LONG_SIDE).coerceAtLeast(0)
        set(v) = p.edit().putInt("maxLongSide", v).apply()

    /** "lower", "balanced" or "higher". */
    var videoQuality: String
        get() = p.getString("videoQuality", null) ?: BuildConfig.VIDEO_QUALITY.lowercase()
        set(v) = p.edit().putString("videoQuality", v).apply()

    /** "hevc" or "h264". */
    var videoCodec: String
        get() = p.getString("videoCodec", null) ?: BuildConfig.VIDEO_CODEC.lowercase()
        set(v) = p.edit().putString("videoCodec", v).apply()

    /** AAC bitrate for converted audio, in kbps (128-320). */
    var audioBitrateKbps: Int
        get() = p.getInt("audioKbps", BuildConfig.AUDIO_BITRATE_KBPS).coerceIn(96, 320)
        set(v) = p.edit().putInt("audioKbps", v).apply()

    var minSavingsPercent: Int
        get() = p.getInt("minSavings", BuildConfig.MIN_SAVINGS_PERCENT).coerceIn(1, 90)
        set(v) = p.edit().putInt("minSavings", v).apply()

    /** Downloads tab lists files at least this big (MB). */
    var downloadsMinMb: Int
        get() = p.getInt("downloadsMinMb", 10).coerceIn(1, 1000)
        set(v) = p.edit().putInt("downloadsMinMb", v).apply()

    var sortOrder: SortOrder
        get() = runCatching { SortOrder.valueOf(p.getString("sort", null)!!) }.getOrDefault(SortOrder.LARGEST)
        set(v) = p.edit().putString("sort", v.name).apply()

    val photoMinBytes get() = BuildConfig.PHOTO_MIN_BYTES
    val videoMinBytes get() = BuildConfig.VIDEO_MIN_BYTES
    val audioMinBytes get() = BuildConfig.AUDIO_MIN_BYTES

    /** Target video bitrate (bits/s) for a given resolution and frame rate. */
    fun videoTargetBitrate(width: Int, height: Int, fps: Double): Long {
        val bitsPerPixel = when (videoQuality) {
            "lower" -> 0.05
            "higher" -> 0.10
            else -> 0.07
        }
        val codecFactor = if (videoCodec == "h264") 1.6 else 1.0
        return (width.toDouble() * height * min(fps, 60.0) * bitsPerPixel * codecFactor)
            .toLong().coerceIn(1_500_000L, 80_000_000L)
    }
}

/** Remembers files this app already compressed so they aren't offered again. */
class ProcessedStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("processed", Context.MODE_PRIVATE)

    fun all(): Set<String> = p.getStringSet("paths", emptySet())?.toSet() ?: emptySet()

    fun add(path: String) {
        val s = HashSet(all())
        s.add(path)
        p.edit().putStringSet("paths", s).apply()
    }

    fun clear() = p.edit().clear().apply()
}

fun formatSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format("%.2f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
    bytes >= 1L shl 10 -> String.format("%.0f KB", bytes / (1L shl 10).toDouble())
    else -> "$bytes B"
}
