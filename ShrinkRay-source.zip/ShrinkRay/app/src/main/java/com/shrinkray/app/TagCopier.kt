package com.shrinkray.app

import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.TagOptionSingleton
import org.jaudiotagger.tag.images.Artwork
import org.jaudiotagger.tag.reference.GenreTypes
import org.jaudiotagger.tag.wav.WavTag
import java.io.File
import java.io.IOException
import java.util.logging.Level
import java.util.logging.Logger

/**
 * Copies song info (title, artist, album, track no., lyrics, ...) and embedded album art
 * from the original audio file into the newly encoded .m4a. Reading the original uses
 * jaudiotagger; writing uses our own strict [Mp4Tagger], then everything is read back
 * and compared byte for byte. Throws IOException if anything important didn't copy,
 * so the original file is kept.
 *
 * Plain Java/Kotlin (no Android classes) so it can be tested on a computer.
 */
object TagCopier {

    data class Result(val fields: Int, val artwork: Int, val dropped: List<String>)

    init {
        // Use jaudiotagger's Android-safe image handling (no java.awt / ImageIO).
        TagOptionSingleton.getInstance().isAndroid = true
        Logger.getLogger("org.jaudiotagger").level = Level.OFF
    }

    /** If these exist in the original they must read back identically, or the file is left alone. */
    private val MUST_MATCH = setOf(
        FieldKey.TITLE, FieldKey.ARTIST, FieldKey.ALBUM, FieldKey.ALBUM_ARTIST,
        FieldKey.TRACK, FieldKey.TRACK_TOTAL, FieldKey.DISC_NO, FieldKey.DISC_TOTAL,
        FieldKey.YEAR, FieldKey.GENRE, FieldKey.LYRICS,
    )

    /** Not copied: art is handled separately; encoder name would be wrong for the new file. */
    private val SKIP = setOf(FieldKey.COVER_ART, FieldKey.ENCODER)

    private val NUMBER_PAIRS = listOf(
        FieldKey.TRACK to FieldKey.TRACK_TOTAL,
        FieldKey.DISC_NO to FieldKey.DISC_TOTAL,
    )

    fun copy(src: File, dst: File): Result {
        val sources = readSourceTags(src)
        val values = LinkedHashMap<FieldKey, String>()
        for (key in FieldKey.entries) {
            if (key in SKIP) continue
            for (t in sources) {
                val v = valuesOf(t, key) ?: continue
                values[key] = v
                break
            }
        }
        splitNumberPairs(values)

        val art: List<Artwork> = sources.asSequence()
            .map { t -> runCatching { t.artworkList.orEmpty() }.getOrDefault(emptyList()) }
            .map { list -> list.filter { (it.binaryData?.size ?: 0) > 0 } }
            .firstOrNull { it.isNotEmpty() } ?: emptyList()

        if (values.isEmpty() && art.isEmpty()) return Result(0, 0, emptyList())

        // Turn the values into MP4 tag atoms.
        val items = ArrayList<Mp4Tagger.Item>()
        val dropped = ArrayList<String>()
        var fields = 0
        for ((key, v) in values) {
            if (key == FieldKey.TRACK_TOTAL || key == FieldKey.DISC_TOTAL) continue
            val item: Mp4Tagger.Item? = when (key) {
                FieldKey.TRACK -> Mp4Tagger.trackOrDisc("trkn", v.toInt(), values[FieldKey.TRACK_TOTAL]?.toInt() ?: 0)
                FieldKey.DISC_NO -> Mp4Tagger.trackOrDisc("disk", v.toInt(), values[FieldKey.DISC_TOTAL]?.toInt() ?: 0)
                FieldKey.BPM -> v.substringBefore('.').trim().toIntOrNull()?.takeIf { it in 1..65535 }?.let { Mp4Tagger.bpm(it) }
                FieldKey.IS_COMPILATION -> Mp4Tagger.compilation(v == "1" || v.equals("true", ignoreCase = true))
                FieldKey.GENRE -> Mp4Tagger.text("\u00A9gen", genreName(v))
                else -> TEXT_ATOMS[key]?.let { Mp4Tagger.text(it, v) }
                    ?: FREEFORM[key]?.let { Mp4Tagger.freeform(it, v) }
            }
            if (item == null) {
                if (key in MUST_MATCH) throw IOException("Couldn't copy ${pretty(key)} \"$v\"")
                dropped += pretty(key)
            } else {
                items += item
                fields++
            }
        }
        if (art.isNotEmpty()) items += Mp4Tagger.covers(art.map { it.binaryData })
        if (items.isEmpty()) return Result(0, 0, dropped)

        // Rebuild the file with the tags, then check it byte for byte before using it.
        val tagged = File(dst.parentFile, dst.name + ".tagged")
        try {
            Mp4Tagger.write(dst, items, tagged)
            val got = Mp4Tagger.readItems(tagged)
            for (it in items) {
                val key = if (it.freeformName != null) "----:" + it.freeformName else it.atom
                val back = got[key] ?: throw IOException("Song info didn't copy correctly")
                if (back.size != it.payloads.size ||
                    back.zip(it.payloads).any { (a, b) -> a.type != b.type || !a.bytes.contentEquals(b.bytes) }
                ) {
                    throw IOException(if (it.atom == "covr") "Album art didn't copy correctly" else "Song info didn't copy correctly")
                }
            }
            Mp4Tagger.checkChunks(dst, tagged)
            if (!dst.delete() || !tagged.renameTo(dst)) throw IOException("Couldn't save the tagged file")
        } finally {
            if (tagged.exists()) tagged.delete()
        }
        return Result(fields, art.size, dropped)
    }

    private val TEXT_ATOMS = mapOf(
        FieldKey.TITLE to "\u00A9nam", FieldKey.ARTIST to "\u00A9ART", FieldKey.ALBUM to "\u00A9alb",
        FieldKey.ALBUM_ARTIST to "aART", FieldKey.YEAR to "\u00A9day", FieldKey.COMPOSER to "\u00A9wrt",
        FieldKey.COMMENT to "\u00A9cmt", FieldKey.LYRICS to "\u00A9lyr", FieldKey.GROUPING to "\u00A9grp",
        FieldKey.COPYRIGHT to "cprt", FieldKey.TITLE_SORT to "sonm", FieldKey.ARTIST_SORT to "soar",
        FieldKey.ALBUM_SORT to "soal", FieldKey.ALBUM_ARTIST_SORT to "soaa", FieldKey.COMPOSER_SORT to "soco",
    )

    private val FREEFORM = mapOf(
        FieldKey.ISRC to "ISRC", FieldKey.RECORD_LABEL to "LABEL", FieldKey.CATALOG_NO to "CATALOGNUMBER",
        FieldKey.MOOD to "MOOD", FieldKey.CONDUCTOR to "CONDUCTOR", FieldKey.LYRICIST to "LYRICIST",
        FieldKey.REMIXER to "REMIXER", FieldKey.LANGUAGE to "LANGUAGE",
        FieldKey.MUSICBRAINZ_TRACK_ID to "MusicBrainz Track Id",
        FieldKey.MUSICBRAINZ_ARTISTID to "MusicBrainz Artist Id",
        FieldKey.MUSICBRAINZ_RELEASEID to "MusicBrainz Album Id",
        FieldKey.MUSICBRAINZ_RELEASEARTISTID to "MusicBrainz Album Artist Id",
    )

    /** ID3 numeric genres like "(17)" or "17" -> "Rock". */
    private fun genreName(v: String): String {
        val m = Regex("""^\(?(\d{1,3})\)?$""").find(v.trim()) ?: return v
        return GenreTypes.getInstanceOf().getValueForId(m.groupValues[1].toInt()) ?: v
    }

    // ------------------------------------------------------------------------

    private const val SEP = "; "

    private fun readSourceTags(src: File): List<Tag> {
        val af = try {
            AudioFileIO.read(src)
        } catch (e: Exception) {
            throw IOException("Couldn't read this file's song info, so it was left alone")
        }
        val t = af.tag ?: return emptyList()
        if (t is WavTag) {
            // WAV can carry an ID3 chunk and/or a LIST INFO chunk; use both (ID3 first).
            return listOfNotNull(
                if (t.isExistingId3Tag()) t.getID3Tag() else null,
                if (t.isExistingInfoTag()) t.getInfoTag() else null,
            )
        }
        return listOf(t)
    }

    private fun valuesOf(t: Tag, key: FieldKey): String? {
        val all = try {
            t.getAll(key)
        } catch (e: Exception) {
            return null // field not supported by this tag format
        } ?: return null
        val clean = all.map { it.trim().trimEnd('\u0000') }.filter { it.isNotEmpty() }.distinct()
        return if (clean.isEmpty()) null else clean.joinToString(SEP)
    }

    /** "3/12" -> track 3, total 12. Non-numeric track numbers (like "A1") can't go in .m4a. */
    private fun splitNumberPairs(values: MutableMap<FieldKey, String>) {
        for ((numKey, totalKey) in NUMBER_PAIRS) {
            val raw = values[numKey] ?: continue
            val parts = raw.split('/')
            val n = parts[0].trim().toIntOrNull()
            val total = parts.getOrNull(1)?.trim()?.toIntOrNull()
            if (n == null) {
                values.remove(numKey)
                continue
            }
            values[numKey] = n.toString()
            if (total != null && values[totalKey] == null) values[totalKey] = total.toString()
        }
        for ((_, totalKey) in NUMBER_PAIRS) {
            val t = values[totalKey] ?: continue
            val n = t.substringBefore('/').trim().toIntOrNull()
            if (n == null) values.remove(totalKey) else values[totalKey] = n.toString()
        }
    }

    private fun pretty(key: FieldKey) =
        key.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
}
