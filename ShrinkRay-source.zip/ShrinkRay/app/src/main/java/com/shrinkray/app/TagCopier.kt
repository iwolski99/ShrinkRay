package com.shrinkray.app

import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.TagOptionSingleton
import org.jaudiotagger.tag.images.Artwork
import org.jaudiotagger.tag.wav.WavTag
import java.io.File
import java.io.IOException
import java.util.logging.Level
import java.util.logging.Logger

/**
 * Copies song info (title, artist, album, track no., lyrics, ...) and embedded album art
 * from the original audio file into the newly encoded .m4a, then reads it back to make
 * sure it really got copied. Throws IOException if anything important didn't copy,
 * so the original file is kept.
 *
 * Plain Java/Kotlin (no Android classes) so it can be tested on a computer.
 */
object TagCopier {

    data class Result(val fields: Int, val artwork: Int, val dropped: List<String>)

    init {
        // Use jaudiotagger's Android-safe image handling (no java.awt / ImageIO).
        TagOptionSingleton.getInstance().isAndroid = true
        Logger.getLogger("org.jaudiotagger").level = Level.OFF
    }

    /** If these exist in the original they must read back identically, or the file is left alone. */
    private val MUST_MATCH = setOf(
        FieldKey.TITLE, FieldKey.ARTIST, FieldKey.ALBUM, FieldKey.ALBUM_ARTIST,
        FieldKey.TRACK, FieldKey.TRACK_TOTAL, FieldKey.DISC_NO, FieldKey.DISC_TOTAL,
        FieldKey.YEAR, FieldKey.GENRE, FieldKey.LYRICS,
    )

    /** Not copied: art is handled separately; encoder name would be wrong for the new file. */
    private val SKIP = setOf(FieldKey.COVER_ART, FieldKey.ENCODER)

    private val NUMBER_PAIRS = listOf(
        FieldKey.TRACK to FieldKey.TRACK_TOTAL,
        FieldKey.DISC_NO to FieldKey.DISC_TOTAL,
    )

    fun copy(src: File, dst: File): Result {
        val sources = readSourceTags(src)
        val values = LinkedHashMap<FieldKey, String>()
        for (key in FieldKey.entries) {
            if (key in SKIP) continue
            for (t in sources) {
                val v = valuesOf(t, key) ?: continue
                values[key] = v
                break
            }
        }
        splitNumberPairs(values)

        val art: List<Artwork> = sources.asSequence()
            .map { t -> runCatching { t.artworkList.orEmpty() }.getOrDefault(emptyList()) }
            .map { list -> list.filter { (it.binaryData?.size ?: 0) > 0 } }
            .firstOrNull { it.isNotEmpty() } ?: emptyList()

        if (values.isEmpty() && art.isEmpty()) return Result(0, 0, emptyList())

        val out = AudioFileIO.read(dst)
        val tag = out.tagOrCreateAndSetDefault
        val written = LinkedHashMap<FieldKey, String>()
        val dropped = ArrayList<String>()
        for ((key, v) in values) {
            try {
                tag.setField(key, v)
                written[key] = v
            } catch (e: Exception) {
                if (key in MUST_MATCH) throw IOException("Couldn't copy ${pretty(key)} \"$v\"")
                dropped += pretty(key)
            }
        }
        for ((i, a) in art.withIndex()) {
            if (i == 0) tag.setField(a) else tag.addField(a)
        }
        out.commit()

        // Read the new file back and check everything important is really there.
        val check = AudioFileIO.read(dst).tag ?: throw IOException("Song info missing after copying")
        for ((key, v) in written) {
            if (key !in MUST_MATCH) continue
            val got = runCatching { check.getAll(key).joinToString(SEP) }.getOrDefault("")
            if (!same(key, v, got)) throw IOException("${pretty(key)} didn't copy correctly")
        }
        val newArt = check.artworkList.orEmpty()
        if (newArt.size != art.size ||
            newArt.zip(art).any { (a, b) -> !a.binaryData.contentEquals(b.binaryData) }
        ) {
            throw IOException("Album art didn't copy correctly")
        }
        return Result(written.size, art.size, dropped)
    }

    // ------------------------------------------------------------------------

    private const val SEP = "; "

    private fun readSourceTags(src: File): List<Tag> {
        val af = try {
            AudioFileIO.read(src)
        } catch (e: Exception) {
            throw IOException("Couldn't read this file's song info, so it was left alone")
        }
        val t = af.tag ?: return emptyList()
        if (t is WavTag) {
            // WAV can carry an ID3 chunk and/or a LIST INFO chunk; use both (ID3 first).
            return listOfNotNull(
                if (t.isExistingId3Tag()) t.getID3Tag() else null,
                if (t.isExistingInfoTag()) t.getInfoTag() else null,
            )
        }
        return listOf(t)
    }

    private fun valuesOf(t: Tag, key: FieldKey): String? {
        val all = try {
            t.getAll(key)
        } catch (e: Exception) {
            return null // field not supported by this tag format
        } ?: return null
        val clean = all.map { it.trim().trimEnd('\u0000') }.filter { it.isNotEmpty() }.distinct()
        return if (clean.isEmpty()) null else clean.joinToString(SEP)
    }

    /** "3/12" -> track 3, total 12. Non-numeric track numbers (like "A1") can't go in .m4a. */
    private fun splitNumberPairs(values: MutableMap<FieldKey, String>) {
        for ((numKey, totalKey) in NUMBER_PAIRS) {
            val raw = values[numKey] ?: continue
            val parts = raw.split('/')
            val n = parts[0].trim().toIntOrNull()
            val total = parts.getOrNull(1)?.trim()?.toIntOrNull()
            if (n == null) {
                values.remove(numKey)
                continue
            }
            values[numKey] = n.toString()
            if (total != null && values[totalKey] == null) values[totalKey] = total.toString()
        }
        for ((_, totalKey) in NUMBER_PAIRS) {
            val t = values[totalKey] ?: continue
            val n = t.substringBefore('/').trim().toIntOrNull()
            if (n == null) values.remove(totalKey) else values[totalKey] = n.toString()
        }
    }

    private fun same(key: FieldKey, expected: String, got: String): Boolean {
        val a = expected.trim()
        val b = got.trim()
        if (a == b) return true
        val ai = a.toIntOrNull()
        val bi = b.toIntOrNull()
        if (ai != null && bi != null) return ai == bi
        if (key == FieldKey.LYRICS) return norm(a) == norm(b)
        if (key == FieldKey.GENRE) {
            // ID3 numeric genres like "(17)" read back as their name ("Rock").
            if (Regex("""^\(?\d+\)?$""").matches(a)) return b.isNotEmpty()
        }
        return false
    }

    private fun norm(s: String) = s.replace("\r\n", "\n").replace('\r', '\n').trim()

    private fun pretty(key: FieldKey) =
        key.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
}
