package com.shrinkray.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.audio.ToInt16PcmAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Codec
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.Modifier
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

sealed interface CompressResult {
    data class Done(val newPath: String, val oldSize: Long, val newSize: Long) : CompressResult
    data class Skipped(val reason: String) : CompressResult
}

/**
 * Compresses one file. Safety rules:
 *  - the compressed copy is written to a hidden temp file next to the original,
 *  - it is checked (opens correctly, same length for video/audio, actually smaller),
 *  - only then does it replace the original. On any error the original is untouched.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class Compressor(private val ctx: Context, private val s: Settings) {

    suspend fun process(f: MediaFile, onProgress: (Int) -> Unit): CompressResult {
        val src = File(f.path)
        if (!src.exists()) throw IOException("File no longer exists")
        val dir = src.parentFile ?: throw IOException("Can't find folder")
        val oldSize = src.length()

        val outExt = when (f.kind) {
            Kind.PHOTO -> f.ext
            Kind.VIDEO -> "mp4"
            Kind.AUDIO -> "m4a"
        }
        val finalFile = if (f.ext == outExt || (f.kind == Kind.VIDEO && f.ext == "m4v")) src
        else uniqueFile(dir, src.nameWithoutExtension, outExt)
        val tmp = File(dir, ".shrinkray_tmp_${System.currentTimeMillis()}.$outExt")

        try {
            when (f.kind) {
                Kind.PHOTO -> withContext(Dispatchers.IO) { compressImage(src, tmp, f.ext) }
                Kind.VIDEO -> {
                    val bitrate = withContext(Dispatchers.IO) { videoBitrateFor(src) }
                        ?: return CompressResult.Skipped("Already efficient")
                    transcode(src, tmp, keepVideo = true, videoBitrate = bitrate, onProgress = onProgress)
                }
                Kind.AUDIO -> {
                    transcode(src, tmp, keepVideo = false, videoBitrate = 0, onProgress = onProgress)
                    // Copy song info + album art and read it back. Throws (keeping the
                    // original) if anything important didn't come across.
                    withContext(Dispatchers.IO) { TagCopier.copy(src, tmp) }
                }
            }

            val newSize = tmp.length()
            if (newSize <= 0) throw IOException("Compressed file came out empty")
            val saved = 100 - (newSize * 100 / oldSize)
            if (saved < s.minSavingsPercent) {
                return CompressResult.Skipped(
                    if (saved <= 0) "Wouldn't get smaller" else "Would only save $saved%"
                )
            }

            withContext(Dispatchers.IO) {
                verify(src, tmp, f.kind)
                replace(src, tmp, finalFile)
            }
            rescan(src, finalFile, f.dateTaken)
            return CompressResult.Done(finalFile.path, oldSize, newSize)
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    // ---------------------------------------------------------------- photos

    private fun compressImage(src: File, out: File, ext: String) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(src.path, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) throw IOException("Can't read this image")

        val longSide = max(w, h)
        val target = if (s.maxLongSide in 1 until longSide) s.maxLongSide else longSide

        // Decode at reduced size first (fast, low memory), then scale exactly.
        var sample = 1
        while (longSide / (sample * 2) >= target) sample *= 2
        while ((w.toLong() / sample) * (h.toLong() / sample) > MAX_DECODE_PIXELS) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp: Bitmap = (try {
            BitmapFactory.decodeFile(src.path, opts)
        } catch (e: OutOfMemoryError) {
            null
        }) ?: throw IOException("Not enough memory to open this image")

        try {
            val bl = max(bmp.width, bmp.height)
            if (bl > target) {
                val scale = target.toFloat() / bl
                val scaled = Bitmap.createScaledBitmap(
                    bmp,
                    max(1, (bmp.width * scale).roundToInt()),
                    max(1, (bmp.height * scale).roundToInt()),
                    true,
                )
                if (scaled !== bmp) {
                    bmp.recycle()
                    bmp = scaled
                }
            }
            val format = if (ext == "webp") Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.JPEG
            FileOutputStream(out).use {
                if (!bmp.compress(format, s.jpegQuality, it)) throw IOException("Encoding failed")
            }
            copyExif(src, out, bmp.width, bmp.height)
        } finally {
            bmp.recycle()
        }
    }

    /** Copies date, GPS, camera info and orientation so the photo stays in place in the gallery. */
    private fun copyExif(src: File, dst: File, width: Int, height: Int) {
        val from = ExifInterface(src.path)
        val to = ExifInterface(dst.path)
        for (tag in exifTags) {
            val v = from.getAttribute(tag) ?: continue
            runCatching { to.setAttribute(tag, v) }
        }
        to.setAttribute(ExifInterface.TAG_PIXEL_X_DIMENSION, width.toString())
        to.setAttribute(ExifInterface.TAG_PIXEL_Y_DIMENSION, height.toString())
        to.saveAttributes() // throws if it fails -> original is kept
    }

    // --------------------------------------------------------- video & audio

    /** Returns the bitrate to encode at, or null if the video is already efficient. */
    private fun videoBitrateFor(src: File): Int? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(src.path)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (w <= 0 || h <= 0 || dur <= 0) throw IOException("Can't read this video")
            val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
            val fps = if (frames != null && frames > 0) (frames * 1000.0 / dur).coerceIn(10.0, 240.0) else 30.0
            val original = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
                ?: (src.length() * 8000 / dur)
            val target = s.videoTargetBitrate(w, h, fps)
            return if (original < target * 1.2) null else target.toInt()
        } finally {
            runCatching { r.release() }
        }
    }

    private suspend fun transcode(
        input: File, out: File, keepVideo: Boolean, videoBitrate: Int, onProgress: (Int) -> Unit,
    ) = withContext(Dispatchers.Main) {
        val baseEncoderFactory = DefaultEncoderFactory.Builder(ctx.applicationContext)
            .setEnableFallback(true)
            .apply {
                if (keepVideo) {
                    setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder().setBitrate(videoBitrate).build()
                    )
                }
            }
            .build()
        val encoderFactory: Codec.EncoderFactory =
            if (keepVideo) baseEncoderFactory
            else AudioBitrateEncoderFactory(baseEncoderFactory, s.audioBitrateKbps * 1000)
        val sampleRate = if (keepVideo) null else withContext(Dispatchers.IO) { audioSampleRate(input) }

        val finished = CompletableDeferred<Unit>()
        val builder = Transformer.Builder(ctx.applicationContext)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished.complete(Unit)
                }

                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException,
                ) {
                    finished.completeExceptionally(exportException)
                }
            })
        if (keepVideo) {
            builder.setVideoMimeType(if (s.videoCodec == "h264") MimeTypes.VIDEO_H264 else MimeTypes.VIDEO_H265)
        }
        val transformer = builder.build()

        val itemBuilder = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
        if (!keepVideo) {
            // Audio-only: drop any cover-art "video" track (art is copied separately by TagCopier).
            itemBuilder.setRemoveVideo(true)
            // 24-bit / 32-bit / float audio (common in WAV and hi-res FLAC) -> 16-bit for the AAC
            // encoder, and 88.2/96/192 kHz -> 48 kHz, the most phone AAC encoders accept.
            // Having effects also forces a real re-encode.
            val resampler = SonicAudioProcessor()
            if (sampleRate == null || sampleRate > 48_000) resampler.setOutputSampleRateHz(48_000)
            itemBuilder.setEffects(Effects(listOf(ToInt16PcmAudioProcessor(), resampler), listOf()))
        }
        transformer.start(itemBuilder.build(), out.absolutePath)

        val holder = ProgressHolder()
        val poller = launch {
            while (isActive) {
                delay(500)
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress)
                }
            }
        }
        try {
            finished.await()
        } catch (e: CancellationException) {
            transformer.cancel()
            throw e
        } finally {
            poller.cancel()
        }
    }

    private fun audioSampleRate(f: File): Int? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.path)
            for (i in 0 until ex.trackCount) {
                val fmt = ex.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true &&
                    fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                ) return fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            }
        } catch (e: Exception) {
            Log.w("ShrinkRay", "Couldn't read sample rate of ${f.path}", e)
        } finally {
            runCatching { ex.release() }
        }
        return null
    }

    /** Same encoders, but asks for our chosen AAC bitrate instead of Media3's 128 kbps default. */
    private class AudioBitrateEncoderFactory(
        private val base: Codec.EncoderFactory,
        private val bitrate: Int,
    ) : Codec.EncoderFactory {
        override fun createForAudioEncoding(format: Format): Codec =
            base.createForAudioEncoding(format.buildUpon().setAverageBitrate(bitrate).build())

        override fun createForVideoEncoding(format: Format): Codec = base.createForVideoEncoding(format)
        override fun audioNeedsEncoding(): Boolean = base.audioNeedsEncoding()
        override fun videoNeedsEncoding(): Boolean = base.videoNeedsEncoding()
    }

    // ------------------------------------------------------------- safety

    private fun verify(src: File, tmp: File, kind: Kind) {
        when (kind) {
            Kind.PHOTO -> {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(tmp.path, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) throw IOException("Compressed photo didn't open")
            }
            Kind.VIDEO, Kind.AUDIO -> {
                val a = durationOf(src)
                val b = durationOf(tmp) ?: throw IOException("Compressed file didn't open")
                if (a != null && abs(a - b) > max(2000L, a / 50)) {
                    throw IOException("Compressed file length didn't match")
                }
                if (kind == Kind.VIDEO && !hasVideo(tmp)) throw IOException("Compressed video has no picture")
            }
        }
    }

    private fun durationOf(f: File): Long? = metadata(f, MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
    private fun hasVideo(f: File): Boolean = metadata(f, MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"

    private fun metadata(f: File, key: Int): String? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            r.extractMetadata(key)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    private fun replace(src: File, tmp: File, finalFile: File) {
        val lastModified = src.lastModified()
        if (!tmp.renameTo(finalFile)) {
            tmp.inputStream().use { i -> FileOutputStream(finalFile).use { o -> i.copyTo(o) } }
            tmp.delete()
        }
        if (finalFile.path != src.path && !src.delete()) {
            throw IOException("Saved ${finalFile.name} but couldn't remove the original")
        }
        finalFile.setLastModified(lastModified)
    }

    /** Tell the gallery about the change, and keep the original "date taken". */
    private suspend fun rescan(src: File, finalFile: File, dateTaken: Long) {
        val paths = if (src.path == finalFile.path) arrayOf(src.path) else arrayOf(src.path, finalFile.path)
        withTimeoutOrNull(20_000) {
            suspendCancellableCoroutine<Unit> { cont ->
                var remaining = paths.size
                MediaScannerConnection.scanFile(ctx, paths, null) { _, _ ->
                    synchronized(this@Compressor) {
                        remaining--
                        if (remaining == 0 && cont.isActive) cont.resume(Unit)
                    }
                }
            }
        }
        if (dateTaken > 0) {
            withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.update(
                        MediaStore.Files.getContentUri("external"),
                        ContentValues().apply { put(MediaStore.MediaColumns.DATE_TAKEN, dateTaken) },
                        "${MediaStore.MediaColumns.DATA} = ?",
                        arrayOf(finalFile.path),
                    )
                } catch (e: Exception) {
                    Log.w("ShrinkRay", "Couldn't restore date for ${finalFile.path}", e)
                }
            }
        }
    }

    private fun uniqueFile(dir: File, base: String, ext: String): File {
        var f = File(dir, "$base.$ext")
        var n = 1
        while (f.exists()) f = File(dir, "${base}_${n++}.$ext")
        return f
    }

    companion object {
        private const val MAX_DECODE_PIXELS = 50_000_000L

        /** EXIF tags we must NOT copy (they describe the old file's layout, or Samsung motion-photo data). */
        private val SKIP_TAGS = setOf(
            "ImageWidth", "ImageLength", "PixelXDimension", "PixelYDimension",
            "ThumbnailImageWidth", "ThumbnailImageLength", "ThumbnailOrientation",
            "JPEGInterchangeFormat", "JPEGInterchangeFormatLength",
            "StripOffsets", "StripByteCounts", "RowsPerStrip", "Compression",
            "BitsPerSample", "SamplesPerPixel", "PhotometricInterpretation",
            "PlanarConfiguration", "NewSubfileType", "SubfileType",
            "YCbCrSubSampling", "MakerNote", "Xmp", "DNGVersion", "DefaultCropSize",
        )

        private val exifTags: List<String> by lazy {
            ExifInterface::class.java.fields
                .filter {
                    Modifier.isStatic(it.modifiers) && it.type == String::class.java &&
                        it.name.startsWith("TAG_")
                }
                .mapNotNull { runCatching { it.get(null) as String }.getOrNull() }
                .filter { it !in SKIP_TAGS }
                .distinct()
        }
    }
}
