package com.shrinkray.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    private val processed = ProcessedStore(app)

    var items by mutableStateOf<List<MediaFile>>(emptyList())
        private set
    var selected by mutableStateOf<Set<String>>(emptySet())
        private set
    val statuses = mutableStateMapOf<String, ItemStatus>()

    var downloads by mutableStateOf<List<MediaFile>>(emptyList())
        private set
    var tab by mutableStateOf(Tab.PHOTO)
    var sort by mutableStateOf(settings.sortOrder)
        private set
    /** Selected file-type filter per tab ("WAV", "MP3", ...); missing = show all types. */
    val typeFilter = mutableStateMapOf<Tab, String>()
    var scanning by mutableStateOf(false)
        private set
    var running by mutableStateOf(false)
        private set
    var currentLabel by mutableStateOf("")
        private set
    var currentProgress by mutableStateOf<Int?>(null)
        private set
    var doneCount by mutableStateOf(0)
        private set
    var totalCount by mutableStateOf(0)
        private set
    var summary by mutableStateOf<String?>(null)

    private var job: Job? = null

    /** Everything in a tab, ignoring the type filter. */
    fun itemsFor(t: Tab): List<MediaFile> =
        if (t == Tab.DOWNLOADS) downloads else items.filter { it.kind == t.kind }

    /** What the list shows: the tab's files, filtered by type and sorted. */
    fun visible(t: Tab): List<MediaFile> {
        val type = typeFilter[t]
        val list = itemsFor(t).filter { type == null || it.type == type }
        return when (sort) {
            SortOrder.LARGEST -> list.sortedByDescending { it.size }
            SortOrder.SMALLEST -> list.sortedBy { it.size }
            SortOrder.NEWEST -> list.sortedByDescending { it.displayDate }
            SortOrder.OLDEST -> list.sortedBy { it.displayDate }
            SortOrder.NAME -> list.sortedBy { it.name.lowercase() }
        }
    }

    /** File types in a tab with how many files of each, most common first. */
    fun typeCounts(t: Tab): List<Pair<String, Int>> =
        itemsFor(t).groupingBy { it.type }.eachCount().toList().sortedByDescending { it.second }

    fun setTypeFilter(t: Tab, type: String?) {
        if (type == null) typeFilter.remove(t) else typeFilter[t] = type
    }

    fun changeSort(o: SortOrder) {
        sort = o
        settings.sortOrder = o
    }

    fun scan() {
        if (scanning || running) return
        scanning = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { MediaRepository.scan(getApplication(), settings, processed.all()) }
                    .getOrDefault(MediaRepository.ScanResult(emptyList(), emptyList()))
            }
            items = result.media
            downloads = result.downloads
            val paths = HashSet<String>()
            result.media.forEach { paths += it.path }
            result.downloads.filter { it.blockedReason == null }.forEach { paths += it.path }
            selected = selected.filterTo(HashSet()) { it in paths }
            // Drop type filters whose type no longer exists.
            for (t in Tab.entries) {
                val f = typeFilter[t] ?: continue
                if (itemsFor(t).none { it.type == f }) typeFilter.remove(t)
            }
            statuses.clear()
            scanning = false
        }
    }

    fun isSelectable(f: MediaFile): Boolean {
        if (f.blockedReason != null) return false
        val st = statuses[f.path]
        return st == null || st is ItemStatus.Failed || st is ItemStatus.Skipped
    }

    fun toggle(f: MediaFile) {
        if (running || !isSelectable(f)) return
        selected = if (f.path in selected) selected - f.path else selected + f.path
    }

    /** "Select all" works on what's currently shown (respects the type filter). */
    fun allSelected(t: Tab): Boolean {
        val list = visible(t).filter { isSelectable(it) }
        return list.isNotEmpty() && list.all { it.path in selected }
    }

    fun toggleAll(t: Tab) {
        if (running) return
        val paths = visible(t).filter { isSelectable(it) }.map { it.path }
        selected = if (allSelected(t)) selected - paths.toSet() else selected + paths
    }

    /** Selected files across all tabs (a file in Downloads can also be in Audio etc.: counted once). */
    fun selectedFiles(): List<MediaFile> =
        (items + downloads).filter { it.path in selected && it.blockedReason == null }.distinctBy { it.path }

    fun start() {
        if (running) return
        val queue = selectedFiles()
        if (queue.isEmpty()) return
        running = true
        summary = null
        doneCount = 0
        totalCount = queue.size
        job = viewModelScope.launch {
            val compressor = Compressor(getApplication(), settings)
            var savedBytes = 0L
            var ok = 0
            var skipped = 0
            var failed = 0
            try {
                for ((i, f) in queue.withIndex()) {
                    currentLabel = "${i + 1} of ${queue.size}: ${f.name}"
                    currentProgress = null
                    statuses[f.path] = ItemStatus.Working
                    try {
                        when (val r = compressor.process(f) { currentProgress = it }) {
                            is CompressResult.Done -> {
                                statuses[f.path] = ItemStatus.Done(r.oldSize, r.newSize)
                                processed.add(r.newPath)
                                savedBytes += r.oldSize - r.newSize
                                ok++
                            }
                            is CompressResult.Skipped -> {
                                statuses[f.path] = ItemStatus.Skipped(r.reason)
                                skipped++
                            }
                        }
                    } catch (e: CancellationException) {
                        statuses.remove(f.path)
                        throw e
                    } catch (e: Throwable) {
                        statuses[f.path] = ItemStatus.Failed(e.message ?: e.javaClass.simpleName)
                        failed++
                    }
                    selected = selected - f.path
                    doneCount = i + 1
                }
            } finally {
                running = false
                currentProgress = null
                summary = buildString {
                    append("Saved ${formatSize(savedBytes)} by compressing $ok file")
                    if (ok != 1) append("s")
                    append(".")
                    if (skipped > 0) append(" $skipped skipped (wouldn't shrink enough, left untouched).")
                    if (failed > 0) append(" $failed failed (originals left untouched).")
                }
            }
        }
    }

    fun cancel() {
        job?.cancel()
    }

    fun clearHistory() = processed.clear()
}
