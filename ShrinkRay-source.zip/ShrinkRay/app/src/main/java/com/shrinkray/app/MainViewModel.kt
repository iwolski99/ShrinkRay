package com.shrinkray.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    private val processed = ProcessedStore(app)

    var items by mutableStateOf<List<MediaFile>>(emptyList())
        private set
    var selected by mutableStateOf<Set<String>>(emptySet())
        private set
    val statuses = mutableStateMapOf<String, ItemStatus>()

    var tab by mutableStateOf(Kind.PHOTO)
    var scanning by mutableStateOf(false)
        private set
    var running by mutableStateOf(false)
        private set
    var currentLabel by mutableStateOf("")
        private set
    var currentProgress by mutableStateOf<Int?>(null)
        private set
    var doneCount by mutableStateOf(0)
        private set
    var totalCount by mutableStateOf(0)
        private set
    var summary by mutableStateOf<String?>(null)

    private var job: Job? = null

    fun itemsFor(kind: Kind) = items.filter { it.kind == kind }

    fun scan() {
        if (scanning || running) return
        scanning = true
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { MediaRepository.scan(getApplication(), settings, processed.all()) }
                    .getOrDefault(emptyList())
            }
            val paths = list.mapTo(HashSet()) { it.path }
            items = list
            selected = selected.filterTo(HashSet()) { it in paths }
            statuses.clear()
            scanning = false
        }
    }

    fun isSelectable(f: MediaFile): Boolean {
        val st = statuses[f.path]
        return st == null || st is ItemStatus.Failed || st is ItemStatus.Skipped
    }

    fun toggle(f: MediaFile) {
        if (running || !isSelectable(f)) return
        selected = if (f.path in selected) selected - f.path else selected + f.path
    }

    fun allSelected(kind: Kind): Boolean {
        val list = itemsFor(kind).filter { isSelectable(it) }
        return list.isNotEmpty() && list.all { it.path in selected }
    }

    fun toggleAll(kind: Kind) {
        if (running) return
        val paths = itemsFor(kind).filter { isSelectable(it) }.map { it.path }
        selected = if (allSelected(kind)) selected - paths.toSet() else selected + paths
    }

    fun selectedFiles(): List<MediaFile> = items.filter { it.path in selected }

    fun start() {
        if (running) return
        val queue = selectedFiles()
        if (queue.isEmpty()) return
        running = true
        summary = null
        doneCount = 0
        totalCount = queue.size
        job = viewModelScope.launch {
            val compressor = Compressor(getApplication(), settings)
            var savedBytes = 0L
            var ok = 0
            var skipped = 0
            var failed = 0
            try {
                for ((i, f) in queue.withIndex()) {
                    currentLabel = "${i + 1} of ${queue.size}: ${f.name}"
                    currentProgress = null
                    statuses[f.path] = ItemStatus.Working
                    try {
                        when (val r = compressor.process(f) { currentProgress = it }) {
                            is CompressResult.Done -> {
                                statuses[f.path] = ItemStatus.Done(r.oldSize, r.newSize)
                                processed.add(r.newPath)
                                savedBytes += r.oldSize - r.newSize
                                ok++
                            }
                            is CompressResult.Skipped -> {
                                statuses[f.path] = ItemStatus.Skipped(r.reason)
                                skipped++
                            }
                        }
                    } catch (e: CancellationException) {
                        statuses.remove(f.path)
                        throw e
                    } catch (e: Throwable) {
                        statuses[f.path] = ItemStatus.Failed(e.message ?: e.javaClass.simpleName)
                        failed++
                    }
                    selected = selected - f.path
                    doneCount = i + 1
                }
            } finally {
                running = false
                currentProgress = null
                summary = buildString {
                    append("Saved ${formatSize(savedBytes)} by compressing $ok file")
                    if (ok != 1) append("s")
                    append(".")
                    if (skipped > 0) append(" $skipped skipped (wouldn't shrink enough, left untouched).")
                    if (failed > 0) append(" $failed failed (originals left untouched).")
                }
            }
        }
    }

    fun cancel() {
        job?.cancel()
    }

    fun clearHistory() = processed.clear()
}
