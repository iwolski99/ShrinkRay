package com.shrinkray.app

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

/** Finds photos, videos and audio on the phone that are worth compressing. */
object MediaRepository {
    private val PHOTO_EXT = setOf("jpg", "jpeg", "webp")
    private val VIDEO_EXT = setOf("mp4", "m4v", "mov", "3gp")
    private val LOSSLESS_AUDIO_EXT = setOf("wav", "flac", "aif", "aiff")
    private val LOSSY_AUDIO_EXT = setOf("mp3", "m4a", "aac", "ogg")

    fun scan(ctx: Context, s: Settings, alreadyDone: Set<String>): List<MediaFile> {
        val found = LinkedHashMap<String, MediaFile>()
        for (vol in MediaStore.getExternalVolumeNames(ctx)) {
            query(ctx, MediaStore.Images.Media.getContentUri(vol), Kind.PHOTO, s.photoMinBytes, found)
            query(ctx, MediaStore.Video.Media.getContentUri(vol), Kind.VIDEO, s.videoMinBytes, found)
            query(ctx, MediaStore.Audio.Media.getContentUri(vol), Kind.AUDIO, s.audioMinBytes, found)
        }
        return found.values
            .filter { it.path !in alreadyDone && isCandidate(it, s) }
            .sortedByDescending { it.size }
    }

    private fun isCandidate(f: MediaFile, s: Settings): Boolean = when (f.kind) {
        Kind.PHOTO -> f.ext in PHOTO_EXT
        Kind.VIDEO -> f.ext in VIDEO_EXT && run {
            if (f.width <= 0 || f.height <= 0 || f.durationMs <= 0) true
            else {
                val estBitrate = f.size * 8000.0 / f.durationMs
                estBitrate > s.videoTargetBitrate(f.width, f.height, 30.0) * 1.2
            }
        }
        Kind.AUDIO -> when (f.ext) {
            in LOSSLESS_AUDIO_EXT -> true
            in LOSSY_AUDIO_EXT -> f.durationMs <= 0 || f.size * 8000.0 / f.durationMs > 200_000
            else -> false
        }
    }

    private fun query(
        ctx: Context, collection: Uri, kind: Kind, minBytes: Long,
        out: MutableMap<String, MediaFile>,
    ) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.DURATION,
        )
        // Some phones reject less common columns; fall back to the basics if so.
        val basic = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
        )
        for (proj in listOf(projection, basic)) {
            if (queryWith(ctx, collection, proj, kind, minBytes, out)) return
        }
    }

    private fun queryWith(
        ctx: Context, collection: Uri, projection: Array<String>, kind: Kind, minBytes: Long,
        out: MutableMap<String, MediaFile>,
    ): Boolean {
        try {
            ctx.contentResolver.query(
                collection, projection,
                "${MediaStore.MediaColumns.SIZE} >= ?", arrayOf(minBytes.toString()), null,
            )?.use { c ->
                val iId = c.getColumnIndex(MediaStore.MediaColumns._ID)
                val iData = c.getColumnIndex(MediaStore.MediaColumns.DATA)
                val iName = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val iTaken = c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
                val iMod = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
                val iW = c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
                val iH = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
                val iDur = c.getColumnIndex(MediaStore.MediaColumns.DURATION)
                if (iId < 0 || iData < 0) return false

                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    // Skip app-private folders and hidden files/folders (incl. our own temp files).
                    if (path.contains("/Android/data/") || path.contains("/.")) continue
                    val id = c.getLong(iId)
                    val taken = c.longOr(iTaken)
                    val modifiedMs = c.longOr(iMod) * 1000
                    out[path] = MediaFile(
                        uri = ContentUris.withAppendedId(collection, id),
                        path = path,
                        name = (if (iName >= 0) c.getString(iName) else null)
                            ?: path.substringAfterLast('/'),
                        folder = path.substringBeforeLast('/').substringAfterLast('/'),
                        size = c.longOr(iSize),
                        kind = kind,
                        width = c.longOr(iW).toInt(),
                        height = c.longOr(iH).toInt(),
                        durationMs = c.longOr(iDur),
                        dateTaken = taken,
                        displayDate = if (taken > 0) taken else modifiedMs,
                    )
                }
            } ?: return false
            return true
        } catch (e: Exception) {
            Log.w("ShrinkRay", "Query failed for $collection", e)
            return false
        }
    }

    private fun Cursor.longOr(index: Int): Long =
        if (index < 0 || isNull(index)) 0L else getLong(index)
}
