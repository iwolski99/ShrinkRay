package com.shrinkray.app

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import android.util.Log

/** Finds photos, videos and audio on the phone that are worth compressing. */
object MediaRepository {
    private val PHOTO_EXT = setOf("jpg", "jpeg", "webp")
    private val VIDEO_EXT = setOf("mp4", "m4v", "mov", "3gp")
    private val LOSSLESS_AUDIO_EXT = setOf("wav", "flac", "aif", "aiff")
    private val LOSSY_AUDIO_EXT = setOf("mp3", "m4a", "aac", "ogg")

    class ScanResult(val media: List<MediaFile>, val downloads: List<MediaFile>)

    fun kindForExt(ext: String): Kind = when (ext) {
        in PHOTO_EXT -> Kind.PHOTO
        in VIDEO_EXT -> Kind.VIDEO
        in LOSSLESS_AUDIO_EXT, in LOSSY_AUDIO_EXT -> Kind.AUDIO
        else -> Kind.OTHER
    }

    fun scan(ctx: Context, s: Settings, alreadyDone: Set<String>): ScanResult {
        val found = LinkedHashMap<String, MediaFile>()
        for (vol in MediaStore.getExternalVolumeNames(ctx)) {
            query(ctx, MediaStore.Images.Media.getContentUri(vol), Kind.PHOTO, s.photoMinBytes, found)
            query(ctx, MediaStore.Video.Media.getContentUri(vol), Kind.VIDEO, s.videoMinBytes, found)
            query(ctx, MediaStore.Audio.Media.getContentUri(vol), Kind.AUDIO, s.audioMinBytes, found)
        }
        val media = found.values
            .filter { it.path !in alreadyDone && isCandidate(it, s) }
            .sortedByDescending { it.size }
        val downloads = runCatching { scanDownloads(s, found, alreadyDone) }
            .onFailure { Log.w("ShrinkRay", "Downloads scan failed", it) }
            .getOrDefault(emptyList())
        return ScanResult(media, downloads)
    }

    /**
     * Every large file in Download (and its subfolders), any type. Photos/videos/audio that
     * can be compressed are selectable; everything else is listed so you can see what's
     * taking space, with the reason it can't be compressed.
     */
    private fun scanDownloads(s: Settings, known: Map<String, MediaFile>, done: Set<String>): List<MediaFile> {
        val root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!root.isDirectory) return emptyList()
        val minBytes = s.downloadsMinMb * 1024L * 1024L
        val out = ArrayList<MediaFile>()
        root.walkTopDown()
            .onEnter { it == root || !it.name.startsWith(".") }
            .filter { it.isFile && !it.name.startsWith(".") && it.length() >= minBytes }
            .take(5000)
            .forEach { file ->
                val base = known[file.path] ?: fileEntry(file)
                val reason = when {
                    file.path in done -> "Already compressed"
                    base.kind == Kind.OTHER -> "Can't compress ${base.type} files"
                    !isCandidate(base, s) -> "Already compact"
                    else -> null
                }
                out += base.copy(blockedReason = reason)
            }
        return out
    }

    private fun fileEntry(f: File): MediaFile {
        val ext = f.name.substringAfterLast('.', "").lowercase()
        return MediaFile(
            uri = Uri.fromFile(f),
            path = f.path,
            name = f.name,
            folder = f.parentFile?.name ?: "",
            size = f.length(),
            kind = kindForExt(ext),
            width = 0,
            height = 0,
            durationMs = 0,
            dateTaken = 0,
            displayDate = f.lastModified(),
        )
    }

    private fun isCandidate(f: MediaFile, s: Settings): Boolean = when (f.kind) {
        Kind.PHOTO -> f.ext in PHOTO_EXT
        Kind.VIDEO -> f.ext in VIDEO_EXT && run {
            if (f.width <= 0 || f.height <= 0 || f.durationMs <= 0) true
            else {
                val estBitrate = f.size * 8000.0 / f.durationMs
                estBitrate > s.videoTargetBitrate(f.width, f.height, 30.0) * 1.2
            }
        }
        Kind.OTHER -> false
        Kind.AUDIO -> when (f.ext) {
            in LOSSLESS_AUDIO_EXT -> true
            // Only re-encode lossy files that are well above the target bitrate.
            in LOSSY_AUDIO_EXT -> f.durationMs <= 0 ||
                f.size * 8000.0 / f.durationMs > s.audioBitrateKbps * 1000 * 1.25
            else -> false
        }
    }

    private fun query(
        ctx: Context, collection: Uri, kind: Kind, minBytes: Long,
        out: MutableMap<String, MediaFile>,
    ) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.DURATION,
        )
        // Some phones reject less common columns; fall back to the basics if so.
        val basic = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
        )
        for (proj in listOf(projection, basic)) {
            if (queryWith(ctx, collection, proj, kind, minBytes, out)) return
        }
    }

    private fun queryWith(
        ctx: Context, collection: Uri, projection: Array<String>, kind: Kind, minBytes: Long,
        out: MutableMap<String, MediaFile>,
    ): Boolean {
        try {
            ctx.contentResolver.query(
                collection, projection,
                "${MediaStore.MediaColumns.SIZE} >= ?", arrayOf(minBytes.toString()), null,
            )?.use { c ->
                val iId = c.getColumnIndex(MediaStore.MediaColumns._ID)
                val iData = c.getColumnIndex(MediaStore.MediaColumns.DATA)
                val iName = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val iTaken = c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
                val iMod = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
                val iW = c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
                val iH = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
                val iDur = c.getColumnIndex(MediaStore.MediaColumns.DURATION)
                if (iId < 0 || iData < 0) return false

                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    // Skip app-private folders and hidden files/folders (incl. our own temp files).
                    if (path.contains("/Android/data/") || path.contains("/.")) continue
                    val id = c.getLong(iId)
                    val taken = c.longOr(iTaken)
                    val modifiedMs = c.longOr(iMod) * 1000
                    out[path] = MediaFile(
                        uri = ContentUris.withAppendedId(collection, id),
                        path = path,
                        name = (if (iName >= 0) c.getString(iName) else null)
                            ?: path.substringAfterLast('/'),
                        folder = path.substringBeforeLast('/').substringAfterLast('/'),
                        size = c.longOr(iSize),
                        kind = kind,
                        width = c.longOr(iW).toInt(),
                        height = c.longOr(iH).toInt(),
                        durationMs = c.longOr(iDur),
                        dateTaken = taken,
                        displayDate = if (taken > 0) taken else modifiedMs,
                    )
                }
            } ?: return false
            return true
        } catch (e: Exception) {
            Log.w("ShrinkRay", "Query failed for $collection", e)
            return false
        }
    }

    private fun Cursor.longOr(index: Int): Long =
        if (index < 0 || isNull(index)) 0L else getLong(index)
}
