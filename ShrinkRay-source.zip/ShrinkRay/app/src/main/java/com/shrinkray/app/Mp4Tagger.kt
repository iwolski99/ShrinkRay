package com.shrinkray.app

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * Small, strict MP4/M4A tag writer.
 *
 * Phones' built-in MP4 writers lay files out in different ways (and some add vendor
 * extras), which general tag libraries can choke on. So instead of editing the file in
 * place, this rebuilds it in the plain standard layout:  ftyp, moov (with our tags), mdat.
 * The audio bytes are copied unchanged; only the index pointing into them is shifted.
 * Afterwards [readItems] and [checkChunks] confirm everything on disk is right.
 */
object Mp4Tagger {

    /** One iTunes-style tag: an atom name (e.g. "©nam", "trkn", "covr", "----") and its data boxes. */
    class Item(val atom: String, val payloads: List<Payload>, val freeformName: String? = null)
    class Payload(val type: Int, val bytes: ByteArray)

    // Data type codes used by iTunes/MP4 tags
    const val TYPE_IMPLICIT = 0
    const val TYPE_UTF8 = 1
    const val TYPE_JPEG = 13
    const val TYPE_PNG = 14
    const val TYPE_INT = 21
    const val TYPE_BMP = 27

    fun text(atom: String, value: String) = Item(atom, listOf(Payload(TYPE_UTF8, value.toByteArray(Charsets.UTF_8))))

    fun freeform(name: String, value: String) =
        Item("----", listOf(Payload(TYPE_UTF8, value.toByteArray(Charsets.UTF_8))), freeformName = name)

    fun trackOrDisc(atom: String, n: Int, total: Int): Item {
        val b = ByteBuffer.allocate(if (atom == "trkn") 8 else 6)
        b.putShort(0); b.putShort(n.toShort()); b.putShort(total.toShort())
        return Item(atom, listOf(Payload(TYPE_IMPLICIT, b.array())))
    }

    fun bpm(v: Int) = Item("tmpo", listOf(Payload(TYPE_INT, ByteBuffer.allocate(2).putShort(v.toShort()).array())))
    fun compilation(v: Boolean) = Item("cpil", listOf(Payload(TYPE_INT, byteArrayOf(if (v) 1 else 0))))

    fun covers(images: List<ByteArray>) = Item("covr", images.map { Payload(imageType(it), it) })

    fun imageType(b: ByteArray): Int = when {
        b.size > 3 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() -> TYPE_PNG
        b.size > 2 && b[0] == 'B'.code.toByte() && b[1] == 'M'.code.toByte() -> TYPE_BMP
        else -> TYPE_JPEG
    }

    // ------------------------------------------------------------------ write

    /** Writes [src] + tags to [out] (a new file). Throws IOException on anything unexpected. */
    fun write(src: File, items: List<Item>, out: File) {
        RandomAccessFile(src, "r").use { raf ->
            val ch = raf.channel
            val top = topLevel(ch)
            val ftyp = top.firstOrNull { it.type == "ftyp" }
            val moovBox = top.singleOrNull { it.type == "moov" } ?: throw IOException("Unexpected file layout: no single moov (${describe(top)})")
            val mdats = top.filter { it.type == "mdat" }
            if (mdats.isEmpty()) throw IOException("Unexpected file layout: no audio data (${describe(top)})")
            if (moovBox.size > 64L * 1024 * 1024) throw IOException("Index too large")

            val moov = readBytes(ch, moovBox.start, moovBox.size.toInt())
            val newMoov = rebuildMoov(moov, moovBox.headerSize, items)

            // New layout: ftyp, moov, mdat...
            val ftypBytes = if (ftyp != null) readBytes(ch, ftyp.start, ftyp.size.toInt()) else DEFAULT_FTYP
            var pos = (ftypBytes.size + newMoov.size).toLong()
            val shifts = mdats.map { m ->
                val newStart = pos
                pos += m.size
                Triple(m.start + m.headerSize, m.start + m.size, newStart - m.start)
            }
            patchChunkOffsets(newMoov) { old ->
                val s = shifts.firstOrNull { old >= it.first && old < it.second }
                    ?: throw IOException("Audio index points outside the audio data")
                old + s.third
            }

            RandomAccessFile(out, "rw").use { o ->
                o.setLength(0)
                val oc = o.channel
                writeFully(oc, ByteBuffer.wrap(ftypBytes))
                writeFully(oc, ByteBuffer.wrap(newMoov))
                for (m in mdats) copyRange(ch, m.start, m.size, oc)
                oc.force(true)
            }
        }
    }

    // ------------------------------------------------------------------ read back

    /** Returns the tag items in [f] as atom -> payloads (freeform atoms keyed "----:name"). */
    fun readItems(f: File): Map<String, List<Payload>> {
        RandomAccessFile(f, "r").use { raf ->
            val ch = raf.channel
            val top = topLevel(ch)
            val moovBox = top.single { it.type == "moov" }
            val moov = readBytes(ch, moovBox.start, moovBox.size.toInt())
            val udta = children(moov, moovBox.headerSize, moov.size).firstOrNull { it.type == "udta" } ?: return emptyMap()
            val meta = children(moov, udta.dataStart, udta.end).firstOrNull { it.type == "meta" } ?: return emptyMap()
            val ilst = children(moov, meta.dataStart + 4, meta.end).firstOrNull { it.type == "ilst" } ?: return emptyMap()
            val result = LinkedHashMap<String, List<Payload>>()
            for (item in children(moov, ilst.dataStart, ilst.end)) {
                var key = item.type
                val payloads = ArrayList<Payload>()
                for (c in children(moov, item.dataStart, item.end)) {
                    when (c.type) {
                        "name" -> key = "----:" + String(moov, c.dataStart + 4, c.end - c.dataStart - 4, Charsets.UTF_8)
                        "data" -> {
                            val type = ByteBuffer.wrap(moov, c.dataStart, 4).int and 0xFFFFFF
                            payloads += Payload(type, moov.copyOfRange(c.dataStart + 8, c.end))
                        }
                    }
                }
                result[key] = payloads
            }
            return result
        }
    }

    /**
     * Checks that every audio chunk the new file's index points to starts with the same
     * bytes as the matching chunk in the original. Catches any mistake in shifting the index.
     */
    fun checkChunks(original: File, rebuilt: File) {
        val a = chunkOffsets(original)
        val b = chunkOffsets(rebuilt)
        if (a.size != b.size || a.isEmpty()) throw IOException("Audio index changed size")
        RandomAccessFile(original, "r").use { ra ->
            RandomAccessFile(rebuilt, "r").use { rb ->
                val step = maxOf(1, a.size / 4000)
                val bufA = ByteBuffer.allocate(16)
                val bufB = ByteBuffer.allocate(16)
                var i = 0
                while (i < a.size) {
                    bufA.clear(); bufB.clear()
                    ra.channel.read(bufA, a[i]); rb.channel.read(bufB, b[i])
                    bufA.flip(); bufB.flip()
                    if (bufA != bufB) throw IOException("Audio data check failed")
                    i += if (i < 64 || i >= a.size - 64) 1 else step
                }
            }
        }
    }

    // ------------------------------------------------------------------ internals

    private class Box(val type: String, val start: Long, val headerSize: Int, val size: Long)
    private class Child(val type: String, val start: Int, val dataStart: Int, val end: Int)

    private val DEFAULT_FTYP: ByteArray = box("ftyp", "M4A ".toByteArray(Charsets.ISO_8859_1) + int(0) +
        "M4A mp42isom".toByteArray(Charsets.ISO_8859_1))

    private fun describe(top: List<Box>) = top.joinToString(", ") { "${it.type}@${it.start}" }

    private fun isValidType(t: String) = t.length == 4 && t.all { it.code in 0x20..0x7E || it.code == 0xA9 }

    /** Top-level boxes. Anything unreadable after both moov and mdat were found (padding, vendor junk) is ignored. */
    private fun topLevel(ch: FileChannel): List<Box> {
        val list = ArrayList<Box>()
        val fileSize = ch.size()
        var pos = 0L
        val hb = ByteBuffer.allocate(16)
        while (pos + 8 <= fileSize) {
            hb.clear(); ch.read(hb, pos); hb.flip()
            var size = hb.int.toLong() and 0xFFFFFFFFL
            val type = String(ByteArray(4).also { hb.get(it) }, Charsets.ISO_8859_1)
            var header = 8
            if (size == 1L) {
                if (hb.remaining() < 8) break
                size = hb.long; header = 16
            } else if (size == 0L) {
                size = fileSize - pos
            }
            val ok = isValidType(type) && size >= header && pos + size <= fileSize
            if (!ok) {
                if (list.any { it.type == "moov" } && list.any { it.type == "mdat" }) break
                throw IOException("Unexpected file layout at byte $pos (${describe(list)})")
            }
            list += Box(type, pos, header, size)
            pos += size
        }
        return list
    }

    private fun children(b: ByteArray, from: Int, to: Int): List<Child> {
        val list = ArrayList<Child>()
        var p = from
        while (p + 8 <= to) {
            var size = ByteBuffer.wrap(b, p, 4).int.toLong() and 0xFFFFFFFFL
            val type = String(b, p + 4, 4, Charsets.ISO_8859_1)
            var header = 8
            if (size == 1L) {
                if (p + 16 > to) break
                size = ByteBuffer.wrap(b, p + 8, 8).long; header = 16
            }
            // Zero size / zero name / overrun = padding or junk at the end of a box: stop there.
            if (size < header || p + size > to || !isValidType(type)) break
            list += Child(type, p, p + header, (p + size).toInt())
            p += size.toInt()
        }
        return list
    }

    private val CONTAINERS = setOf("trak", "mdia", "minf", "stbl")

    private fun rebuildMoov(moov: ByteArray, headerSize: Int, items: List<Item>): ByteArray {
        val body = ByteArrayOutputStream()
        for (c in children(moov, headerSize, moov.size)) {
            if (c.type == "udta") continue // replaced by ours (phone muxers only put location/vendor info here)
            body.write(moov, c.start, c.end - c.start)
        }
        if (items.isNotEmpty()) body.write(udta(items))
        return box("moov", body.toByteArray())
    }

    private fun patchChunkOffsets(moov: ByteArray, map: (Long) -> Long) {
        fun walk(from: Int, to: Int) {
            for (c in children(moov, from, to)) {
                when {
                    c.type in CONTAINERS -> walk(c.dataStart, c.end)
                    c.type == "stco" -> {
                        val n = ByteBuffer.wrap(moov, c.dataStart + 4, 4).int
                        for (i in 0 until n) {
                            val p = c.dataStart + 8 + 4 * i
                            val v = map(ByteBuffer.wrap(moov, p, 4).int.toLong() and 0xFFFFFFFFL)
                            if (v > 0xFFFFFFFFL) throw IOException("File too large")
                            ByteBuffer.wrap(moov, p, 4).putInt(v.toInt())
                        }
                    }
                    c.type == "co64" -> {
                        val n = ByteBuffer.wrap(moov, c.dataStart + 4, 4).int
                        for (i in 0 until n) {
                            val p = c.dataStart + 8 + 8 * i
                            ByteBuffer.wrap(moov, p, 8).putLong(map(ByteBuffer.wrap(moov, p, 8).long))
                        }
                    }
                }
            }
        }
        val top = children(moov, 0, moov.size).single()
        walk(top.dataStart, top.end)
    }

    private fun chunkOffsets(f: File): LongArray {
        RandomAccessFile(f, "r").use { raf ->
            val ch = raf.channel
            val moovBox = topLevel(ch).single { it.type == "moov" }
            val moov = readBytes(ch, moovBox.start, moovBox.size.toInt())
            val out = ArrayList<Long>()
            fun walk(from: Int, to: Int) {
                for (c in children(moov, from, to)) {
                    when {
                        c.type in CONTAINERS -> walk(c.dataStart, c.end)
                        c.type == "stco" -> {
                            val n = ByteBuffer.wrap(moov, c.dataStart + 4, 4).int
                            for (i in 0 until n) out += ByteBuffer.wrap(moov, c.dataStart + 8 + 4 * i, 4).int.toLong() and 0xFFFFFFFFL
                        }
                        c.type == "co64" -> {
                            val n = ByteBuffer.wrap(moov, c.dataStart + 4, 4).int
                            for (i in 0 until n) out += ByteBuffer.wrap(moov, c.dataStart + 8 + 8 * i, 8).long
                        }
                    }
                }
            }
            walk(moovBox.headerSize, moov.size)
            return out.toLongArray()
        }
    }

    private fun udta(items: List<Item>): ByteArray {
        val ilst = ByteArrayOutputStream()
        for (it in items) {
            val inner = ByteArrayOutputStream()
            if (it.freeformName != null) {
                inner.write(box("mean", int(0) + "com.apple.iTunes".toByteArray(Charsets.UTF_8)))
                inner.write(box("name", int(0) + it.freeformName.toByteArray(Charsets.UTF_8)))
            }
            for (p in it.payloads) inner.write(box("data", int(p.type) + int(0) + p.bytes))
            ilst.write(box(it.atom, inner.toByteArray()))
        }
        val hdlr = box("hdlr", int(0) + int(0) + "mdirappl".toByteArray(Charsets.ISO_8859_1) + int(0) + int(0) + byteArrayOf(0))
        val meta = box("meta", int(0) + hdlr + box("ilst", ilst.toByteArray()))
        return box("udta", meta)
    }

    private fun box(type: String, body: ByteArray): ByteArray {
        val t = type.toByteArray(Charsets.ISO_8859_1)
        require(t.size == 4)
        return int(8 + body.size) + t + body
    }

    private fun int(v: Int) = ByteBuffer.allocate(4).putInt(v).array()

    private fun readBytes(ch: FileChannel, pos: Long, len: Int): ByteArray {
        val b = ByteBuffer.allocate(len)
        var p = pos
        while (b.hasRemaining()) {
            val n = ch.read(b, p)
            if (n < 0) throw IOException("Unexpected end of file")
            p += n
        }
        return b.array()
    }

    private fun writeFully(ch: FileChannel, b: ByteBuffer) {
        while (b.hasRemaining()) ch.write(b)
    }

    private fun copyRange(src: FileChannel, pos: Long, len: Long, dst: FileChannel) {
        var done = 0L
        while (done < len) {
            val n = src.transferTo(pos + done, len - done, dst)
            if (n <= 0) throw IOException("Copy failed")
            done += n
        }
    }
}
