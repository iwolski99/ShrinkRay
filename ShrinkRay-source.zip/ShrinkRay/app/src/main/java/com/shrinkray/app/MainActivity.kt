package com.shrinkray.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings as AndroidSettings
import android.util.LruCache
import android.util.Size
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val dark = isSystemInDarkTheme()
            val scheme = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var hasAccess by remember { mutableStateOf(Environment.isExternalStorageManager()) }
                    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
                        hasAccess = Environment.isExternalStorageManager()
                    }
                    if (hasAccess) MainScreen(viewModel()) else PermissionScreen()
                }
            }
        }
    }

    fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

@Composable
private fun PermissionScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("One permission needed", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(
            "To replace your photos, videos and audio with smaller versions in the same folders, " +
                "${stringResource(R.string.app_name)} needs \"All files access\".\n\n" +
                "Nothing is changed until you pick files and confirm. Nothing is uploaded anywhere: " +
                "everything happens on your phone.",
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { openAllFilesSettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text("Open settings and allow")
        }
    }
}

private fun openAllFilesSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(AndroidSettings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
        )
    } catch (e: Exception) {
        ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var showConfirm by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { if (vm.items.isEmpty()) vm.scan() }
    DisposableEffect(vm.running) {
        (ctx as? MainActivity)?.keepScreenOn(vm.running)
        onDispose { }
    }
    BackHandler(enabled = vm.running) { /* stay on screen while working */ }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = { vm.scan() }, enabled = !vm.running && !vm.scanning) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Rescan")
                    }
                    IconButton(onClick = { showSettings = true }, enabled = !vm.running) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        bottomBar = { BottomPanel(vm, onCompress = { showConfirm = true }) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = vm.tab.ordinal) {
                Kind.entries.forEach { k ->
                    Tab(
                        selected = vm.tab == k,
                        onClick = { vm.tab = k },
                        text = { Text("${k.label} (${vm.itemsFor(k).size})") },
                    )
                }
            }

            vm.summary?.let { msg ->
                Card(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { vm.summary = null }) { Text("OK") }
                    }
                }
            }

            val list = vm.itemsFor(vm.tab)
            if (vm.scanning) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Looking for large files…")
                    }
                }
            } else {

            Row(
                Modifier.fillMaxWidth().clickable(enabled = !vm.running && list.isNotEmpty()) { vm.toggleAll(vm.tab) }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(
                    checked = vm.allSelected(vm.tab),
                    onCheckedChange = { vm.toggleAll(vm.tab) },
                    enabled = !vm.running && list.isNotEmpty(),
                )
                Text("Select all ${vm.tab.label.lowercase()}", fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text(
                    formatSize(list.sumOf { it.size }) + " total",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(end = 8.dp),
                )
            }
            HorizontalDivider()

            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No ${vm.tab.label.lowercase()} worth compressing were found.",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.path }) { f -> FileRow(vm, f) }
                }
            }
            }
        }
    }

    if (showConfirm) ConfirmDialog(vm, onDismiss = { showConfirm = false }, onConfirm = {
        showConfirm = false
        vm.start()
    })
    if (showSettings) SettingsDialog(vm.settings, onDismiss = {
        showSettings = false
        vm.scan()
    }, onClearHistory = { vm.clearHistory() })
}

@Composable
private fun BottomPanel(vm: MainViewModel, onCompress: () -> Unit) {
    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            if (vm.running) {
                Text(vm.currentLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                val p = vm.currentProgress
                if (p != null) LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                Text(
                    "${vm.doneCount} of ${vm.totalCount} done · keep the app open",
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Stop after cancelling this file")
                }
            } else {
                val sel = vm.selectedFiles()
                Button(
                    onClick = onCompress,
                    enabled = sel.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    Text(
                        if (sel.isEmpty()) "Select files to compress"
                        else "Compress ${sel.size} file${if (sel.size == 1) "" else "s"} (${formatSize(sel.sumOf { it.size })})"
                    )
                }
            }
        }
    }
}

private val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())

@Composable
private fun FileRow(vm: MainViewModel, f: MediaFile) {
    val status = vm.statuses[f.path]
    val selectable = vm.isSelectable(f)
    Row(
        Modifier.fillMaxWidth()
            .clickable(enabled = selectable && !vm.running) { vm.toggle(f) }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = f.path in vm.selected,
            onCheckedChange = { vm.toggle(f) },
            enabled = selectable && !vm.running,
        )
        Thumb(f)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                "${f.folder} · ${if (f.displayDate > 0) dateFormat.format(Date(f.displayDate)) else ""}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            when (status) {
                null -> {}
                ItemStatus.Working -> Text("Compressing…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                is ItemStatus.Done -> Text(
                    "✓ ${formatSize(status.oldSize)} → ${formatSize(status.newSize)} (−${100 - status.newSize * 100 / status.oldSize}%)",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary,
                )
                is ItemStatus.Skipped -> Text("Skipped: ${status.reason}", style = MaterialTheme.typography.bodySmall)
                is ItemStatus.Failed -> Text("Failed: ${status.reason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, maxLines = 2)
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(formatSize(f.size), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

private object ThumbCache {
    val cache = LruCache<String, ImageBitmap>(200)
}

@Composable
private fun Thumb(f: MediaFile) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(ThumbCache.cache.get(f.path), f.path) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.loadThumbnail(f.uri, Size(160, 160), null).asImageBitmap()
                        .also { ThumbCache.cache.put(f.path, it) }
                } catch (e: Exception) {
                    null
                }
            }
        }
    }
    Box(
        Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) Image(b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Text(if (f.kind == Kind.AUDIO) "♪" else if (f.kind == Kind.VIDEO) "▶" else "▢")
    }
}

@Composable
private fun ConfirmDialog(vm: MainViewModel, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val sel = vm.selectedFiles()
    val s = vm.settings
    var understood by remember { mutableStateOf(false) }
    val kinds = sel.map { it.kind }.toSet()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Replace ${sel.size} file${if (sel.size == 1) "" else "s"}?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "${sel.size} file${if (sel.size == 1) "" else "s"} (${formatSize(sel.sumOf { it.size })}) will be " +
                        "compressed and the originals permanently replaced in the same folders. This can't be undone."
                )
                Spacer(Modifier.height(10.dp))
                if (Kind.PHOTO in kinds) Text(
                    "• Photos: quality ${s.jpegQuality}, " +
                        (if (s.maxLongSide > 0) "max ${s.maxLongSide}px on the long side. " else "original resolution. ") +
                        "Samsung motion photos become still photos.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (Kind.VIDEO in kinds) Text(
                    "• Videos: re-encoded as ${if (s.videoCodec == "h264") "H.264" else "HEVC"} (${s.videoQuality} quality), same resolution. Can take a while.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (Kind.AUDIO in kinds) Text(
                    "• Audio: converted to .m4a (AAC ${s.audioBitrateKbps} kbps). Song info and album art " +
                        "are copied over and checked; if they don't copy perfectly the original is kept. " +
                        "Files that weren't .m4a get a new .m4a name, so playlists pointing at the old " +
                        "file name may need refreshing.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    "• Files that wouldn't shrink by at least ${s.minSavingsPercent}% are left alone.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { understood = !understood },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(checked = understood, onCheckedChange = { understood = it })
                    Text("I understand, replace these files")
                }
            }
        },
        confirmButton = {
            Button(onClick = onConfirm, enabled = understood) { Text("Compress") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SettingsDialog(s: Settings, onDismiss: () -> Unit, onClearHistory: () -> Unit) {
    var quality by remember { mutableFloatStateOf(s.jpegQuality.toFloat()) }
    var maxSide by remember { mutableIntStateOf(s.maxLongSide) }
    var vq by remember { mutableStateOf(s.videoQuality) }
    var codec by remember { mutableStateOf(s.videoCodec) }
    var audioKbps by remember { mutableIntStateOf(s.audioBitrateKbps) }
    var minSave by remember { mutableFloatStateOf(s.minSavingsPercent.toFloat()) }
    var cleared by remember { mutableStateOf(false) }

    fun save() {
        s.jpegQuality = quality.roundToInt()
        s.maxLongSide = maxSide
        s.videoQuality = vq
        s.videoCodec = codec
        s.audioBitrateKbps = audioKbps
        s.minSavingsPercent = minSave.roundToInt()
    }

    AlertDialog(
        onDismissRequest = { save(); onDismiss() },
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Photo quality: ${quality.roundToInt()}", fontWeight = FontWeight.Medium)
                Text("85–90 looks the same as the original to the eye.", style = MaterialTheme.typography.bodySmall)
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 60f..95f, steps = 34)

                Text("Photo size (long side)", fontWeight = FontWeight.Medium)
                ChipRow(
                    listOf(0 to "Original", 4000 to "4000px", 3000 to "3000px", 2048 to "2048px"),
                    maxSide,
                ) { maxSide = it }

                Spacer(Modifier.height(8.dp))
                Text("Video quality", fontWeight = FontWeight.Medium)
                ChipRow(listOf("lower" to "Smaller", "balanced" to "Balanced", "higher" to "Higher"), vq) { vq = it }

                Text("Video format", fontWeight = FontWeight.Medium)
                ChipRow(listOf("hevc" to "HEVC (smaller)", "h264" to "H.264 (plays anywhere)"), codec) { codec = it }

                Spacer(Modifier.height(8.dp))
                Text("Audio quality (AAC)", fontWeight = FontWeight.Medium)
                Text("256 kbps sounds the same as CD/WAV to almost everyone.", style = MaterialTheme.typography.bodySmall)
                ChipRow(listOf(192 to "192", 256 to "256", 320 to "320 kbps"), audioKbps) { audioKbps = it }

                Spacer(Modifier.height(8.dp))
                Text("Only replace if at least ${minSave.roundToInt()}% smaller", fontWeight = FontWeight.Medium)
                Slider(value = minSave, onValueChange = { minSave = it }, valueRange = 5f..50f, steps = 44)

                TextButton(onClick = { onClearHistory(); cleared = true }, enabled = !cleared) {
                    Text(if (cleared) "History cleared" else "Forget which files were already compressed")
                }
            }
        },
        confirmButton = { Button(onClick = { save(); onDismiss() }) { Text("Save") } },
    )
}

@Composable
private fun <T> ChipRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}
