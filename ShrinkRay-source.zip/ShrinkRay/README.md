# ShrinkRay

Android app that shrinks big photos, videos and audio files and puts the smaller
version back in the same folder, replacing the original. Everything runs on the
phone; nothing is uploaded.

## How it works

- Scans your phone for large photos (JPG/WebP), videos (MP4/MOV/3GP) and audio
  (WAV/FLAC/AIFF, plus high-bitrate MP3/M4A/OGG). Biggest files first.
- Nothing is selected by default. Tick files one by one, or use **Select all**.
- Before anything changes you get a confirmation screen with a required
  "I understand" tick box.
- Each file is compressed to a hidden temp file, checked (it opens, video/audio
  length matches, and it is really smaller), and only then replaces the original.
  If anything goes wrong the original is left alone.
- Photos keep their date, location, camera info and rotation (EXIF). Videos keep
  their date in the gallery.
- Files that wouldn't shrink by at least `min_savings_percent` are skipped.

What changes:
- Photos: re-saved at quality 88 and, by default, at most 4000 px on the long side
  (12 MP). Samsung motion photos become still photos.
- Videos: re-encoded to HEVC (or H.264) at the same resolution. Keep the app open
  while it works. Long videos take a while.
- Audio: converted to AAC `.m4a` (256 kbps by default, changeable in the app).
  24-bit/32-bit/float audio becomes 16-bit and 88.2-192 kHz becomes 48 kHz.
  Song info (title, artist, album, album artist, track/disc numbers, year, genre,
  composer, comment, lyrics, ...) and all embedded album art are copied into the
  new file and read back to check them. If anything important doesn't match, the
  original is kept. Tested with FLAC, MP3 (ID3 v2.3/v2.4), WAV (ID3 and LIST INFO,
  16/24/32-bit float, up to 96 kHz), M4A, OGG and AIFF. Unusual custom fields
  (e.g. ReplayGain) are not copied. WAV/FLAC/MP3 files get a new `.m4a` file name.

## Building with GitHub Actions

1. Put `ShrinkRay-source.zip` (this folder, zipped) and `config.yaml` in the root
   of your repo.
2. Put `build.yml` at `.github/workflows/build.yml`.
3. Every time the zip or `config.yaml` changes, the app is built. The APK appears
   under **Releases**.

### Optional: install updates without uninstalling

By default each build is signed with a new one-time key, so Android makes you
uninstall the old version before installing a newer one. To keep one key, create
a keystore once (on a computer):

    keytool -genkeypair -keystore release.jks -storetype PKCS12 -alias release \
      -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=ShrinkRay"
    base64 -w0 release.jks

Then add these under repo **Settings → Secrets and variables → Actions**:
`KEYSTORE_BASE64` (the base64 text), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`release`).
Never commit the keystore file to a public repo.
